=== WikiSearch ===
Contributors: yourname
Tags: wikipedia, links, search, gutenberg
Requires at least: 5.8
Tested up to: 6.6
Requires PHP: 7.4
Stable tag: 0.1.0
License: MIT
License URI: https://opensource.org/licenses/MIT

Turn simple links into instant Wikipedia lookups on your site.

== Description ==
WikiSearch scans page content for links whose URL is exactly `wikisearch` and converts them into links to Wikipedia based on the visible text.

**Fastest way to use it in Gutenberg:** highlight some text, click the link button, and enter `wikisearch` as the URL. Publish — your link will point to the matching Wikipedia page.

== Installation ==
1. Upload the `wikisearch` folder to `/wp-content/plugins/` or upload the ZIP in **Plugins → Add New → Upload Plugin**.
2. Activate *WikiSearch* via **Plugins → Installed Plugins**.

== Usage ==
- In the editor, select text, click the link icon, and type `wikisearch` as the URL.
- On the front-end, the plugin converts that placeholder into a Wikipedia link using the anchor text.

== Screenshots ==
1. Linking with `wikisearch` in the Gutenberg editor.

== Changelog ==
= 0.1.0 =
* Initial release.

== Frequently Asked Questions ==
= Can I choose a different language (e.g., fr.wikipedia.org)? =
Not yet. Future versions will add a setting for language selection.
